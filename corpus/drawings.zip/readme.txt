Workshop drawings, revision C.
